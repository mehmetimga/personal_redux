import './App.css';
import UsersList from './components/UsersList';

function App() {
  return (
    <div>
      <UsersList />
    </div>
  );
}

export default App;
